package Automate_an_E_Commerce_Web_Application.Automate_an_E_Commerce_Web_Application;


import java.io.File;
import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;



public class FlipkartTestChrome {

    private WebDriver driver;
	
    @BeforeClass
    public void setUp() {
        // Set up Chrome WebDriver using WebDriverManager
		WebDriverManager.chromedriver().setup();	 
		driver =new ChromeDriver();
		// Maximizing the window and setting implicit wait        
		// Navigating to the Flipkart homepage
		driver.get("https://www.flipkart.com/");
		// Maximizing the window and setting implicit wait
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);      
    }
    
    @AfterClass
	public void afterClass() throws InterruptedException {
    	// Wait before quitting the browser to observe the result
    	Thread.sleep(2000);
    	driver.quit();
		
	}
    
    
    
    
    @Test(priority = 1)
    public void closeLogin() throws InterruptedException, IOException {
        System.out.println("\nChrome Browser Result:\n");
        System.out.println(driver.getTitle());

        // Find the login pop-up element using the CSS selector
        WebElement loginPopup = null;
        try {
            // Use WebDriverWait to wait for the login pop-up element to become available
            WebDriverWait wait = new WebDriverWait(driver, 10);
        	loginPopup = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("body > div._2Sn47c > div > div > button")));
        	takeScreenshot(driver,"LoginPopUpChrome");
//            loginPopup.click();
//            Thread.sleep(1000);
           // Test to close the login pop-up if it exists
            Reporter.log("Test to close the login pop-up if it exists");
            System.out.println("\nLogin pop-up is present");
            
        } catch (NoSuchElementException e) {
            // If the login pop-up element is not found, it means the login pop-up doesn't exist            
            System.out.println("Login pop-up is not present. Continuing with other progress.");
            Reporter.log("Login pop-up is not present. Continuing with other progress.");
            // You can also log the exception if needed:
            // e.printStackTrace();
        }

        // Check if the login pop-up element is found (i.e., login pop-up exists)
        if (loginPopup != null) {
            // If the login pop-up exists, click on it to close it
            loginPopup.click();
            Thread.sleep(1000);
        }
    }

	
	
	@Test(priority = 2)
	public void scroll() throws InterruptedException, IOException {
		// Test to check the page load time and scroll to the bottom of the page
		// Determine page load time with performance test
		long startTime = System.currentTimeMillis();
	
	    // Add code to wait for page to load
	  	Thread.sleep(2000);
	    long endTime = System.currentTimeMillis();
	    long pageLoadTime = endTime - startTime;
	    System.out.println("\nPage load time: " + pageLoadTime + " milliseconds");

		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		takeScreenshot(driver,"scroll");
		System.out.println("\nNavigated to bottom of the page");
		Thread.sleep(2000);
		js.executeScript("window.scrollBy(0,-document.body.scrollHeight)", "");
		Reporter.log("Test to check the page load time and scroll to the bottom of the page");
		System.out.println("\nScroll Feature available");
		Thread.sleep(2000);
		
	}
	
	@Test(priority = 3)
	public void searchProduct() throws InterruptedException, IOException {
		// Test to search for a product and measure the time to load the search results
		Thread.sleep(1000);
		driver.findElement(By.name("q")).sendKeys("iPhone 13");
		Thread.sleep(1000);
		By search = By.cssSelector(
				"#container > div > div._1kfTjk > div._1rH5Jn > div._2Xfa2_ > div._1cmsER > form > div > button > svg");
		driver.findElement(search).click();

		Thread.sleep(3000);
		By load = By.cssSelector(
				"#container > div > div._36fx1h._6t1WkM._3HqJxg > div._1YokD2._2GoDe3 > div:nth-child(2) > div:nth-child(9) > div > div");
		long start = System.currentTimeMillis();
		driver.findElement(load).click();
		long finish = System.currentTimeMillis();
		long totalTime = finish - start;
		Reporter.log("Test to search for a product and measure the time to load the search results");
		System.out.println("\nTime to load page in millisecs - " + totalTime);
		takeScreenshot(driver,"searchproduct");
	}
	
	
	
	@Test(priority = 4)
	public void loadImage() throws InterruptedException, IOException {

		String url = "https://www.flipkart.com/apple-iphone-13-blue-256-gb/p/itmd68a015aa1e39?pid=MOBG6VF566ZTUVFR&lid=LSTMOBG6VF566ZTUVFR2RQLVU&marketplace=FLIPKART&q=iPhone+13&store=tyy%2F4io&srno=s_1_8&otracker=search&otracker1=search&fm=organic&iid=1c0c7402-fe4f-4f45-9aa8-cc59dffe8503.MOBG6VF566ZTUVFR.SEARCH&ppt=hp&ppn=homepage&ssid=i4t60bsv4g0000001665375424769&qH=c3d519be0191fbf8";
		driver.get(url);
		Thread.sleep(3000);
		//driver.navigate().refresh();

		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(10, TimeUnit.SECONDS)
				.pollingEvery(2, TimeUnit.SECONDS).ignoring(NoSuchElementException.class); 
		wait.until(new Function<WebDriver, WebElement>() {

			@Test
			public WebElement apply(WebDriver driver) {
				WebElement img = driver.findElement(By.xpath(
						"//*[@id=\"container\"]/div/div[3]/div[1]/div[2]/div[9]/div[4]/div[3]/div/div/div/div[1]/img"));

				if (img.isDisplayed()) {
					System.out.println("\nImage Loaded");
					Reporter.log("\\nImage Loaded");
					return img;
				} else {
					System.out.println("\nFluent Wait Fail!, Element Not Loaded Yet");
					Reporter.log("\\nFluent Wait Fail!, Element Not Loaded Yet");
					return null;
				}
			}
		});
		takeScreenshot(driver,"pageLoad");
	}
	
	@Test(priority = 5)
	public void scrollFrequency() throws InterruptedException, IOException {
		Thread.sleep(2000);
		long start = System.currentTimeMillis();
		WebElement element = driver.findElement(By.cssSelector(
				"#container > div > div._2c7YLP.UtUXW0._6t1WkM._3HqJxg > div._1YokD2._2GoDe3 > div._1YokD2._3Mn1Gg.col-8-12 > div._1YokD2._3Mn1Gg > div:nth-child(7) > div > div:nth-child(3) > div > div > div:nth-child(1)"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		long stop = System.currentTimeMillis();
		long totalTime = stop - start;
		Reporter.log("");
		System.out.println("\nScroll Frequency in millisecs - " + totalTime);
		takeScreenshot(driver,"scrollfrequency");

	}
	
	
	
	@Test(priority = 6)
	public void downloadImages() throws InterruptedException, IOException {
		WebElement img = driver.findElement(By
				.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[2]/div[9]/div[4]/div[3]/div/div/div/div[1]/img"));
		Boolean present = (Boolean) ((JavascriptExecutor) driver).executeScript("return arguments[0].complete "
				+ "&& typeof arguments[0].naturalWidth != \"undefined\" " + "&& arguments[0].naturalWidth > 0", img);

		if (present) {
			System.out.println("\nImage present");
			Reporter.log("\nImage present");
		} else {
			System.out.println("\nImage not present");
			Reporter.log("\nImage not present");
		}
		takeScreenshot(driver,"downloadImages");
	}
	
	
	@Test(priority = 7)
	public void screenResolution() throws InterruptedException, IOException {
		Thread.sleep(1000);
		Dimension dimension = new Dimension(720, 1080);
		driver.manage().window().setSize(dimension);
		Thread.sleep(3000);

		Dimension dimension1 = new Dimension(1280, 800);
		driver.manage().window().setSize(dimension1);
		Thread.sleep(3000);

		Dimension dimension2 = new Dimension(2256, 1504);
		driver.manage().window().setSize(dimension2);

		JavascriptExecutor js = (JavascriptExecutor) driver;
		int contentHeight = ((Number) js.executeScript("return window.innerHeight")).intValue();
		int contentWidth = ((Number) js.executeScript("return window.innerWidth")).intValue();
		System.out.println("\nHeight: " + contentHeight + " Width: " + contentWidth + "\n");
		Reporter.log("\nHeight: " + contentHeight + " Width: " + contentWidth + "\n");
		takeScreenshot(driver,"screenshotResolution");

	}
	
	
	
	public static void takeScreenshot(WebDriver wd,String fileName) throws IOException {
		//take the screenshot and store it as a file format
		File file=((TakesScreenshot)wd).getScreenshotAs(OutputType.FILE);
		//now copy the screen shot to the specified location 
		FileUtils.copyFile(file,new File("B:\\Phase-3-Spring\\Automate-an-E-Commerce-Web-Application\\"+fileName+".png"));
		Reporter.log("Screenshot taken and saved as: " + fileName + ".png");
	}
	  
    
    
    
}
