package Automate_an_E_Commerce_Web_Application.Automate_an_E_Commerce_Web_Application;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
